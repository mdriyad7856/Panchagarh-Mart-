# Panchagarh Mart Admin — সেটআপ নির্দেশিকা

## ১) কম্পিউটারে চালানো
1. Node.js LTS ইনস্টল করুন।
2. এই ফোল্ডার Terminal/Command Prompt-এ খুলুন।
3. `npm install` চালান।
4. `.env.example` কপি করে `.env` নাম দিন।
5. `.env` ফাইলে আপনার Supabase Project URL এবং একই Project-এর Publishable Key বসান।
6. `npm run dev` চালান। Terminal-এ দেখানো local URL ব্রাউজারে খুলুন।

## ২) গুরুত্বপূর্ণ
- Frontend-এ শুধু Project URL এবং Publishable Key ব্যবহার করবেন।
- `service_role`, `sb_secret_` বা Database Password কখনো `.env`-এর VITE_ ভেরিয়েবলে দেবেন না।
- Admin user তৈরি করার পর SQL Editor-এ নিজের ইমেইল বসিয়ে এই কোড চালান:

```sql
update public.profiles
set role = 'admin'
where id = (select id from auth.users where email = 'YOUR_EMAIL');
```

## ৩) Storage policies
Storage > Policies-এ `products` bucket-এর জন্য authenticated admin upload/update/delete policy তৈরি করুন। নিচের SQL SQL Editor-এ চালানো যায়:

```sql
create policy "Admin upload product images"
on storage.objects for insert to authenticated
with check (bucket_id = 'products' and public.is_admin());

create policy "Admin update product images"
on storage.objects for update to authenticated
using (bucket_id = 'products' and public.is_admin())
with check (bucket_id = 'products' and public.is_admin());

create policy "Admin delete product images"
on storage.objects for delete to authenticated
using (bucket_id = 'products' and public.is_admin());

create policy "Public read product images"
on storage.objects for select to anon, authenticated
using (bucket_id = 'products');
```

## ৪) সীমাবদ্ধতা / পরবর্তী ধাপ
এটি প্রথম Admin MVP: Login, Dashboard summary, Product CRUD, image upload, category create, order/customer list। নিরাপদ public checkout/order creation, order status update, payment integration, analytics charts, password reset এবং production hardening পরের ধাপে যোগ করতে হবে।
