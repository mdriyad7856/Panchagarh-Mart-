# Supabase setup

The app uses the Supabase project already configured in Replit. The database
script creates the store tables and policies, but it does not insert sample
products, customers, or orders.

## 1. Review and apply the schema

1. Back up your Supabase project before changing an existing database.
2. Open **Supabase Dashboard → SQL Editor** for the same project as
   `VITE_SUPABASE_URL`.
3. Review and run `schema.sql`.
4. Confirm the tables are visible under **Table Editor** and that the
   `products` Storage bucket exists.

The script is safe to re-run for the schema it creates, but `CREATE TABLE IF NOT
EXISTS` does not convert a differently shaped legacy table. If your existing
`products`, `orders`, or `profiles` tables have different column types or
relationships, reconcile those before applying the script; do not drop tables
or overwrite existing store data.

The `products` bucket is made public only when the script creates it. If a
bucket with that name already exists, its visibility is left unchanged. Review
its existing files before making it public; public product images can be viewed
by anyone.

## 2. Create an administrator

Create or use an account in **Supabase Dashboard → Authentication → Users**.
The database trigger creates a `profiles` row with the customer role. Promote
the store administrator in the SQL Editor, replacing the email:

```sql
insert into public.profiles (id, full_name, role)
select id, coalesce(raw_user_meta_data ->> 'full_name', ''), 'admin'
  from auth.users
  where email = 'YOUR_ADMIN_EMAIL'
on conflict (id) do update set role = 'admin';
```

The app's admin login uses Supabase Auth. Admin table writes, inventory
adjustments, support replies, and image management are restricted by RLS and
the administrator role.

## 3. Environment variables

Set these shared Replit variables to values from the same Supabase project:

- `VITE_SUPABASE_URL` — the project URL, such as
  `https://your-project-ref.supabase.co`
- `VITE_SUPABASE_PUBLISHABLE_KEY` — the public key beginning
  `sb_publishable_`

`VITE_SUPABASE_ANON_KEY` is still accepted for an older public anon JWT key.
Never put an `sb_secret_` or `service_role` key in any `VITE_` variable; those
values would be exposed to browser users.

After changing environment variables, restart the web app.

## 4. What the schema enables

- Product and category management with public reads limited to active listings
- Public image reads and admin-only product image upload, replacement, and delete
- Admin customer, order, discount, campaign, inventory, support, and store-setting
  access
- Cash on Delivery orders created through `place_cod_order`; the database
  recalculates prices, checks stock and discounts, records order line snapshots,
  and reserves inventory in one transaction
- No card payments are collected

## 5. Store routes

- `/` — Supabase-authenticated admin dashboard
- `/store` — public storefront with product browse, cart, and Cash on Delivery

The storefront starts empty until products and categories are added in the
admin. The Email section stores campaign records; sending email requires a
separate mail delivery provider and is not performed by this schema.
