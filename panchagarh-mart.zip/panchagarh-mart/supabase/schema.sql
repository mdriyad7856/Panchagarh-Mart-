-- Panchagarh Mart Supabase schema
-- Apply in the Supabase SQL Editor. This script creates no demo products or orders.
-- Review existing tables before applying to a project that already has store data.

create sequence if not exists public.panchagarh_order_number_seq start with 1000;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'customer' check (role in ('admin', 'customer')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique,
  description text not null default '',
  image_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.categories(id) on delete set null,
  name text not null,
  slug text not null unique,
  sku text unique,
  description text not null default '',
  price numeric(12, 2) not null check (price >= 0),
  stock integer not null default 0 check (stock >= 0),
  image_url text,
  image_path text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  phone text not null unique,
  email text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.discounts (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  discount_type text not null check (discount_type in ('percentage', 'fixed')),
  value numeric(12, 2) not null check (value > 0),
  minimum_order numeric(12, 2) not null default 0 check (minimum_order >= 0),
  starts_at timestamptz,
  ends_at timestamptz,
  usage_limit integer check (usage_limit is null or usage_limit >= 0),
  used_count integer not null default 0 check (used_count >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (discount_type <> 'percentage' or value <= 100),
  check (ends_at is null or starts_at is null or ends_at > starts_at)
);

create sequence if not exists public.panchagarh_order_id_seq;

create table if not exists public.orders (
  id bigint primary key default nextval('public.panchagarh_order_id_seq'),
  order_number text not null unique default (
    'PM-' || lpad(nextval('public.panchagarh_order_number_seq')::text, 8, '0')
  ),
  customer_id uuid references public.customers(id) on delete set null,
  customer_name text not null,
  phone text not null,
  email text,
  shipping_address text not null,
  delivery_notes text,
  subtotal numeric(12, 2) not null check (subtotal >= 0),
  delivery_fee numeric(12, 2) not null default 0 check (delivery_fee >= 0),
  discount_amount numeric(12, 2) not null default 0 check (discount_amount >= 0),
  discount_code text,
  total_amount numeric(12, 2) not null check (total_amount >= 0),
  status text not null default 'pending'
    check (status in ('pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled')),
  payment_method text not null default 'cash_on_delivery'
    check (payment_method = 'cash_on_delivery'),
  payment_status text not null default 'unpaid'
    check (payment_status in ('unpaid', 'paid', 'refunded')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter sequence public.panchagarh_order_id_seq owned by public.orders.id;

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id bigint not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  product_image_url text,
  quantity integer not null check (quantity > 0),
  unit_price numeric(12, 2) not null check (unit_price >= 0),
  line_total numeric(12, 2) not null check (line_total >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.inventory_movements (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  quantity_delta integer not null check (quantity_delta <> 0),
  reason text not null,
  actor_id uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.campaigns (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  channel text not null check (channel in ('marketing', 'email')),
  subject text not null default '',
  body text not null default '',
  status text not null default 'draft' check (status in ('draft', 'scheduled', 'archived')),
  scheduled_at timestamptz,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.support_messages (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  phone text not null,
  email text,
  subject text not null default 'Store inquiry',
  message text not null,
  status text not null default 'new' check (status in ('new', 'in_progress', 'resolved')),
  admin_reply text,
  replied_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.store_settings (
  id smallint primary key default 1 check (id = 1),
  store_name text not null default 'Panchagarh Mart',
  support_phone text not null default '',
  support_email text not null default '',
  store_address text not null default '',
  delivery_fee numeric(12, 2) not null default 0 check (delivery_fee >= 0),
  currency text not null default 'BDT' check (currency = 'BDT'),
  updated_at timestamptz not null default now()
);

create index if not exists products_category_id_idx on public.products(category_id);
create index if not exists products_active_created_idx on public.products(is_active, created_at desc);
create index if not exists orders_created_at_idx on public.orders(created_at desc);
create index if not exists orders_status_created_idx on public.orders(status, created_at desc);
create index if not exists order_items_order_id_idx on public.order_items(order_id);
create index if not exists inventory_movements_product_created_idx
  on public.inventory_movements(product_id, created_at desc);
create index if not exists support_messages_status_created_idx
  on public.support_messages(status, created_at desc);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = public, pg_temp
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

do $$
declare
  table_name text;
begin
  foreach table_name in array array[
    'profiles', 'categories', 'products', 'customers', 'discounts',
    'orders', 'campaigns', 'support_messages', 'store_settings'
  ]
  loop
    execute format('drop trigger if exists set_updated_at on public.%I', table_name);
    execute format(
      'create trigger set_updated_at before update on public.%I for each row execute function public.set_updated_at()',
      table_name
    );
  end loop;
end;
$$;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1
    from public.profiles
    where id = (select auth.uid())
      and role = 'admin'
  );
$$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    'customer'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.adjust_inventory(
  p_product_id uuid,
  p_quantity_delta integer,
  p_reason text
)
returns integer
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  new_stock integer;
begin
  if not public.is_admin() then
    raise exception 'Admin access required' using errcode = '42501';
  end if;
  if p_quantity_delta = 0 or length(trim(coalesce(p_reason, ''))) = 0 then
    raise exception 'A non-zero quantity and reason are required' using errcode = '22023';
  end if;

  update public.products
  set stock = stock + p_quantity_delta
  where id = p_product_id
    and stock + p_quantity_delta >= 0
  returning stock into new_stock;

  if new_stock is null then
    raise exception 'Product not found or stock would become negative' using errcode = '22023';
  end if;

  insert into public.inventory_movements (product_id, quantity_delta, reason, actor_id)
  values (p_product_id, p_quantity_delta, trim(p_reason), auth.uid());

  return new_stock;
end;
$$;

create or replace function public.get_admin_summary()
returns jsonb
language plpgsql
stable
security definer
set search_path = public, pg_temp
as $$
begin
  if not public.is_admin() then
    raise exception 'Admin access required' using errcode = '42501';
  end if;

  return jsonb_build_object(
    'product_count', (select count(*) from public.products),
    'active_product_count', (select count(*) from public.products where is_active),
    'order_count', (select count(*) from public.orders),
    'customer_count', (select count(*) from public.customers),
    'pending_order_count', (select count(*) from public.orders where status = 'pending'),
    'delivered_order_count', (select count(*) from public.orders where status = 'delivered'),
    'cod_order_count', (select count(*) from public.orders where payment_method = 'cash_on_delivery'),
    'low_stock_count', (select count(*) from public.products where is_active and stock <= 5),
    'delivered_revenue', (
      select coalesce(sum(total_amount), 0)
      from public.orders
      where status = 'delivered'
    ),
    'paid_revenue', (
      select coalesce(sum(total_amount), 0)
      from public.orders
      where payment_status = 'paid'
    ),
    'unpaid_total', (
      select coalesce(sum(total_amount), 0)
      from public.orders
      where payment_status = 'unpaid'
    ),
    'order_status_counts', coalesce((
      select jsonb_object_agg(status, order_count)
      from (
        select status, count(*) as order_count
        from public.orders
        group by status
      ) as status_summary
    ), '{}'::jsonb),
    'recent_orders', coalesce((
      select jsonb_agg(to_jsonb(recent_order))
      from (
        select id, order_number, customer_name, phone, total_amount, status,
          payment_status, created_at
        from public.orders
        order by created_at desc
        limit 10
      ) as recent_order
    ), '[]'::jsonb)
  );
end;
$$;

create or replace function public.place_cod_order(
  p_customer_name text,
  p_phone text,
  p_shipping_address text,
  p_items jsonb,
  p_email text default null,
  p_delivery_notes text default null,
  p_discount_code text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  item_product record;
  item_quantity integer;
  expected_products integer;
  locked_products integer := 0;
  v_customer_id uuid;
  v_order_id bigint;
  v_order_number text;
  subtotal_amount numeric(12, 2) := 0;
  delivery_amount numeric(12, 2) := 0;
  discount_amount numeric(12, 2) := 0;
  total_amount numeric(12, 2) := 0;
  discount_row public.discounts%rowtype;
begin
  if length(trim(coalesce(p_customer_name, ''))) not between 2 and 120 then
    raise exception 'Enter a valid customer name' using errcode = '22023';
  end if;
  if length(trim(coalesce(p_phone, ''))) not between 5 and 40 then
    raise exception 'Enter a valid phone number' using errcode = '22023';
  end if;
  if length(trim(coalesce(p_shipping_address, ''))) not between 5 and 500 then
    raise exception 'Enter a valid delivery address' using errcode = '22023';
  end if;
  if p_items is null or jsonb_typeof(p_items) <> 'array' then
    raise exception 'Cart is empty or too large' using errcode = '22023';
  end if;
  if jsonb_array_length(p_items) = 0 or jsonb_array_length(p_items) > 50 then
    raise exception 'Cart is empty or too large' using errcode = '22023';
  end if;
  if exists (
    select 1
    from jsonb_array_elements(p_items) as item(value)
    where jsonb_typeof(item.value) <> 'object'
      or nullif(item.value ->> 'product_id', '') is null
      or coalesce(item.value ->> 'quantity', '') !~ '^[0-9]+$'
  ) then
    raise exception 'Cart contains an invalid item' using errcode = '22023';
  end if;

  select count(distinct (item.value ->> 'product_id')::uuid)
  into expected_products
  from jsonb_array_elements(p_items) as item(value);

  if expected_products = 0 then
    raise exception 'Cart contains no valid products' using errcode = '22023';
  end if;

  -- Lock all requested active products before checking or changing stock.
  for item_product in
    select p.id, p.name, p.price, p.stock, p.image_url
    from public.products p
    where p.is_active
      and p.id in (
        select distinct (item.value ->> 'product_id')::uuid
        from jsonb_array_elements(p_items) as item(value)
      )
    order by p.id
    for update
  loop
    select coalesce(sum((item.value ->> 'quantity')::integer), 0)
    into item_quantity
    from jsonb_array_elements(p_items) as item(value)
    where (item.value ->> 'product_id')::uuid = item_product.id;

    if item_quantity < 1 or item_quantity > 100 then
      raise exception 'Product quantity is invalid' using errcode = '22023';
    end if;
    if item_product.stock < item_quantity then
      raise exception 'Insufficient stock for %', item_product.name using errcode = '22023';
    end if;

    subtotal_amount := subtotal_amount + item_product.price * item_quantity;
    locked_products := locked_products + 1;
  end loop;

  if locked_products <> expected_products then
    raise exception 'One or more products are unavailable' using errcode = '22023';
  end if;

  select coalesce(s.delivery_fee, 0)
  into delivery_amount
  from public.store_settings s
  where s.id = 1;
  delivery_amount := coalesce(delivery_amount, 0);

  if nullif(trim(coalesce(p_discount_code, '')), '') is not null then
    select *
    into discount_row
    from public.discounts d
    where d.code = upper(trim(p_discount_code))
      and d.is_active
      and (d.starts_at is null or d.starts_at <= now())
      and (d.ends_at is null or d.ends_at > now())
    for update;

    if not found then
      raise exception 'Discount code is invalid or expired' using errcode = '22023';
    end if;
    if discount_row.usage_limit is not null
      and discount_row.used_count >= discount_row.usage_limit then
      raise exception 'Discount code usage limit has been reached' using errcode = '22023';
    end if;
    if subtotal_amount < discount_row.minimum_order then
      raise exception 'Order does not meet the discount minimum' using errcode = '22023';
    end if;

    if discount_row.discount_type = 'percentage' then
      discount_amount := round(subtotal_amount * discount_row.value / 100, 2);
    else
      discount_amount := least(subtotal_amount, discount_row.value);
    end if;
  end if;

  total_amount := greatest(0, subtotal_amount + delivery_amount - discount_amount);

  insert into public.customers as existing_customer (full_name, phone, email)
  values (trim(p_customer_name), trim(p_phone), nullif(trim(coalesce(p_email, '')), ''))
  on conflict (phone) do update
    set full_name = excluded.full_name,
        email = coalesce(excluded.email, existing_customer.email)
  returning id into v_customer_id;

  insert into public.orders (
    customer_id, customer_name, phone, email, shipping_address, delivery_notes,
    subtotal, delivery_fee, discount_amount, discount_code, total_amount,
    status, payment_method, payment_status
  )
  values (
    v_customer_id, trim(p_customer_name), trim(p_phone),
    nullif(trim(coalesce(p_email, '')), ''),
    trim(p_shipping_address), nullif(trim(coalesce(p_delivery_notes, '')), ''),
    subtotal_amount, delivery_amount, discount_amount,
    nullif(upper(trim(coalesce(p_discount_code, ''))), ''),
    total_amount, 'pending', 'cash_on_delivery', 'unpaid'
  )
  returning id, order_number into v_order_id, v_order_number;

  for item_product in
    select p.id, p.name, p.price, p.stock, p.image_url
    from public.products p
    where p.is_active
      and p.id in (
        select distinct (item.value ->> 'product_id')::uuid
        from jsonb_array_elements(p_items) as item(value)
      )
    order by p.id
  loop
    select coalesce(sum((item.value ->> 'quantity')::integer), 0)
    into item_quantity
    from jsonb_array_elements(p_items) as item(value)
    where (item.value ->> 'product_id')::uuid = item_product.id;

    insert into public.order_items (
      order_id, product_id, product_name, product_image_url,
      quantity, unit_price, line_total
    )
    values (
      v_order_id, item_product.id, item_product.name, item_product.image_url,
      item_quantity, item_product.price, item_product.price * item_quantity
    );

    update public.products
    set stock = stock - item_quantity
    where id = item_product.id;
  end loop;

  if discount_row.id is not null then
    update public.discounts
    set used_count = used_count + 1
    where id = discount_row.id;
  end if;

  return jsonb_build_object(
    'order_id', v_order_id,
    'order_number', v_order_number,
    'subtotal', subtotal_amount,
    'delivery_fee', delivery_amount,
    'discount_amount', discount_amount,
    'total_amount', total_amount
  );
end;
$$;

alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.customers enable row level security;
alter table public.discounts enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.inventory_movements enable row level security;
alter table public.campaigns enable row level security;
alter table public.support_messages enable row level security;
alter table public.store_settings enable row level security;

drop policy if exists profiles_read_self_or_admin on public.profiles;
create policy profiles_read_self_or_admin on public.profiles
  for select to authenticated
  using (id = (select auth.uid()) or public.is_admin());

drop policy if exists categories_public_active_read on public.categories;
create policy categories_public_active_read on public.categories
  for select to anon, authenticated
  using (is_active or public.is_admin());
drop policy if exists categories_admin_manage on public.categories;
create policy categories_admin_manage on public.categories
  for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists products_public_active_read on public.products;
create policy products_public_active_read on public.products
  for select to anon, authenticated
  using (is_active or public.is_admin());
drop policy if exists products_admin_manage on public.products;
create policy products_admin_manage on public.products
  for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists customers_admin_manage on public.customers;
create policy customers_admin_manage on public.customers
  for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists discounts_admin_manage on public.discounts;
create policy discounts_admin_manage on public.discounts
  for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists orders_admin_manage on public.orders;
create policy orders_admin_manage on public.orders
  for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists order_items_admin_manage on public.order_items;
create policy order_items_admin_manage on public.order_items
  for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists inventory_movements_admin_read on public.inventory_movements;
create policy inventory_movements_admin_read on public.inventory_movements
  for select to authenticated using (public.is_admin());

drop policy if exists campaigns_admin_manage on public.campaigns;
create policy campaigns_admin_manage on public.campaigns
  for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists support_messages_public_submit on public.support_messages;
create policy support_messages_public_submit on public.support_messages
  for insert to anon, authenticated
  with check (
    status = 'new'
    and admin_reply is null
    and replied_at is null
    and length(trim(customer_name)) between 2 and 120
    and length(trim(phone)) between 5 and 40
    and length(trim(message)) between 1 and 4000
  );
drop policy if exists support_messages_admin_manage on public.support_messages;
create policy support_messages_admin_manage on public.support_messages
  for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists store_settings_public_read on public.store_settings;
create policy store_settings_public_read on public.store_settings
  for select to anon, authenticated using (true);
drop policy if exists store_settings_admin_manage on public.store_settings;
create policy store_settings_admin_manage on public.store_settings
  for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

grant usage on schema public to anon, authenticated;
grant execute on function public.is_admin() to anon, authenticated;
grant select on public.categories, public.products, public.store_settings to anon, authenticated;
grant select, insert, update, delete on
  public.profiles, public.categories, public.products, public.customers,
  public.discounts, public.orders, public.order_items, public.inventory_movements,
  public.campaigns, public.support_messages, public.store_settings
to authenticated;
grant insert on public.support_messages to anon;
grant usage, select on sequence public.panchagarh_order_id_seq,
  public.panchagarh_order_number_seq to authenticated;

revoke all on function public.handle_new_user() from public;
revoke all on function public.adjust_inventory(uuid, integer, text) from public;
revoke all on function public.get_admin_summary() from public;
revoke all on function public.place_cod_order(text, text, text, jsonb, text, text, text) from public;
grant execute on function public.adjust_inventory(uuid, integer, text) to authenticated;
grant execute on function public.get_admin_summary() to authenticated;
grant execute on function public.place_cod_order(text, text, text, jsonb, text, text, text)
  to anon, authenticated;

insert into storage.buckets (id, name, public)
values ('products', 'products', true)
on conflict (id) do nothing;

grant usage on schema storage to anon, authenticated;
grant select on storage.objects to anon, authenticated;
grant insert, update, delete on storage.objects to authenticated;

drop policy if exists panchagarh_product_images_public_read on storage.objects;
create policy panchagarh_product_images_public_read on storage.objects
  for select to anon, authenticated
  using (bucket_id = 'products');

drop policy if exists panchagarh_product_images_admin_insert on storage.objects;
create policy panchagarh_product_images_admin_insert on storage.objects
  for insert to authenticated
  with check (bucket_id = 'products' and public.is_admin());

drop policy if exists panchagarh_product_images_admin_update on storage.objects;
create policy panchagarh_product_images_admin_update on storage.objects
  for update to authenticated
  using (bucket_id = 'products' and public.is_admin())
  with check (bucket_id = 'products' and public.is_admin());

drop policy if exists panchagarh_product_images_admin_delete on storage.objects;
create policy panchagarh_product_images_admin_delete on storage.objects
  for delete to authenticated
  using (bucket_id = 'products' and public.is_admin());

comment on function public.place_cod_order(text, text, text, jsonb, text, text, text)
  is 'Validates active products, computes prices, reserves stock, and creates COD orders atomically.';
