# Panchagarh Mart Admin

This project runs the React dashboard from the provided source ZIP. Its existing
layout, dark theme, and Supabase client have been preserved.

The public storefront and full admin data setup are documented in
`supabase/README.md`.

## Supabase connection

Add these project environment variables to connect the dashboard:

- `VITE_SUPABASE_URL` — your Supabase project URL
- `VITE_SUPABASE_PUBLISHABLE_KEY` — the matching project's
  `sb_publishable_...` key

Existing projects can use `VITE_SUPABASE_ANON_KEY` with a legacy anon JWT
instead. Use only public keys in this browser app. Never use a Supabase
`sb_secret_`/service-role key or database password in a `VITE_` variable. The
client rejects secret-key formats and malformed project URLs before connecting.

Until both values are configured, the app displays its built-in Supabase setup
screen. After connecting, the source expects Supabase Auth plus the `products`,
`orders`, `profiles`, and `categories` tables and a `products` Storage bucket
with appropriate access policies. See `README-BN.md` for the original setup
notes.
