import { useEffect, useMemo, useState } from "react";
import {
  LayoutDashboard, ShoppingCart, Package, Users, ChartNoAxesCombined,
  Megaphone, Wallet, Boxes, Percent, Grid2X2, Mail, MessageCircle,
  FileText, Settings, CircleHelp, LogOut, Search, Bell, Plus, Pencil,
  Trash2, Menu, X, RefreshCw, TrendingUp, Clock3, Check,
  Truck, Minus, Store, ArrowUpRight, ClipboardList
} from "lucide-react";
import { Route, Switch } from "wouter";
import { supabase } from "./supabase";
import "./admin.css";
import { addCartProduct, cartItemCount, cartSubtotal, changeCartQuantity } from "./lib/cart";
import {
  getDashboardData, listProducts, saveProduct, deleteProduct,
  uploadProductImage, deleteProductImage, listCategories, saveCategory,
  deleteCategory, listOrders, getOrderItems, updateOrder, listCustomers,
  updateCustomer, createCustomer, deleteCustomer, listDiscounts, saveDiscount, deleteDiscount, listCampaigns,
  saveCampaign, deleteCampaign, listInventoryMovements, adjustInventory,
  listSupportMessages, updateSupportMessage, submitSupportMessage, getStoreSettings, saveStoreSettings,
  placeCodOrder
} from "./lib/storeApi";
import "./store.css";

const nav = [
  ["Dashboard", LayoutDashboard], ["Orders", ShoppingCart], ["Products", Package],
  ["Customers", Users], ["Analytics", ChartNoAxesCombined], ["Marketing", Megaphone],
  ["Finance", Wallet], ["Inventory", Boxes], ["Discounts", Percent],
  ["Categories", Grid2X2], ["Email", Mail], ["Chat", MessageCircle],
  ["Reports", FileText], ["Settings", Settings]
];
const money = value => `৳${Number(value || 0).toLocaleString("en-BD", { maximumFractionDigits: 2 })}`;
const date = value => value ? new Date(value).toLocaleDateString("en-BD", { day: "numeric", month: "short", year: "numeric" }) : "—";
const statusOptions = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"];

function App() {
  return <Switch>
    <Route path="/store" component={Storefront} />
    <Route path="/" component={AdminApp} />
    <Route component={RouteNotFound} />
  </Switch>;
}

function AdminApp() {
  const [session, setSession] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [section, setSection] = useState("Dashboard");
  const [mobileNav, setMobileNav] = useState(false);
  const [data, setData] = useState({ products: [], orders: [], customers: [], overview: null });
  const [globalSearch, setGlobalSearch] = useState("");
  const [loadingData, setLoadingData] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  useEffect(() => {
    if (!supabase) { setAuthLoading(false); return undefined; }
    let mounted = true;
    supabase.auth.getSession()
      .then(({ data: auth }) => {
        if (mounted) { setSession(auth.session); setAuthLoading(false); }
      })
      .catch(err => {
        if (mounted) { setError(err.message || "Could not check your session."); setAuthLoading(false); }
      });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => {
      if (mounted) setSession(next);
    });
    return () => { mounted = false; listener.subscription.unsubscribe(); };
  }, []);

  async function refresh() {
    if (!session) return;
    setLoadingData(true); setError("");
    try {
      const [overview, products, orders, customers] = await Promise.all([
        getDashboardData(), listProducts(), listOrders(), listCustomers()
      ]);
      setData({ overview, products: products || [], orders: orders || [], customers: customers || [] });
    } catch (err) { setError(err.message || "Could not load store data."); }
    finally { setLoadingData(false); }
  }
  useEffect(() => { refresh(); }, [session]);
  if (authLoading) return <div className="center">Loading Panchagarh Mart…</div>;
  if (!supabase) return <Setup />;
  if (!session) return <Login />;
  const setMessage = value => { setNotice(value); window.setTimeout(() => setNotice(""), 3500); };
  const term = globalSearch.toLowerCase();
  const globalResults = globalSearch ? [
    ...data.products.filter(p => p.name.toLowerCase().includes(term)).slice(0, 4).map(p => ({ label: p.name, hint: "Product", section: "Products" })),
    ...data.orders.filter(o => `${o.order_number || ""} ${o.customer_name || ""} ${o.phone || ""}`.toLowerCase().includes(term)).slice(0, 4).map(o => ({ label: `${o.order_number || `#${o.id}`} · ${o.customer_name}`, hint: "Order", section: "Orders" })),
    ...data.customers.filter(c => `${c.full_name || ""} ${c.phone || ""}`.toLowerCase().includes(term)).slice(0, 4).map(c => ({ label: c.full_name || c.phone, hint: "Customer", section: "Customers" }))
  ] : [];
  return <div className="shell">
    <aside className={`sidebar ${mobileNav ? "show" : ""}`}>
      <div className="brand"><div className="brandIcon">P</div><div><b>Panchagarh Mart</b><small>E-commerce Admin</small></div><button className="closeNav" aria-label="Close menu" onClick={() => setMobileNav(false)}><X /></button></div>
      <nav>{nav.map(([name, Icon]) => <button key={name} className={section === name ? "active" : ""} onClick={() => { setSection(name); setMobileNav(false); }}><Icon size={18} /><span>{name}</span>{name === "Orders" && data.orders.length > 0 && <i>{data.orders.filter(o => o.status === "pending").length || data.orders.length}</i>}</button>)}</nav>
      <div className="sideBottom"><a href="/store" className="storeNavLink"><Store size={18} />View storefront</a><button onClick={() => setSection("Chat")}><CircleHelp size={18} />Help Center</button><button onClick={() => supabase.auth.signOut()}><LogOut size={18} />Logout</button></div>
    </aside>
    {mobileNav && <div className="scrim" onClick={() => setMobileNav(false)} />}
    <main className="main">
      <header className="topbar"><button className="menuBtn" aria-label="Open menu" onClick={() => setMobileNav(true)}><Menu /></button><div className="search adminSearch"><Search size={17} /><input aria-label="Search all store data" placeholder="Search products, orders, customers…" value={globalSearch} onChange={e => setGlobalSearch(e.target.value)} />{globalSearch && <div className="globalSearchResults">{globalResults.length ? globalResults.map((result, index) => <button key={`${result.hint}-${index}`} onClick={() => { setSection(result.section); setGlobalSearch(""); }}>{result.label}<small>{result.hint}</small></button>) : <p>No matching records</p>}</div>}</div><div className="topRight"><span className="dateLabel">Panchagarh, Bangladesh</span><Bell size={20} /><div className="avatar">{session.user.email?.[0]?.toUpperCase()}</div><div className="user"><b>{session.user.email}</b><small>Administrator</small></div></div></header>
      <section className="content">
        <div className="welcome"><div><p className="eyebrow">STORE OVERVIEW</p><h1>Welcome back</h1><p>Here’s what’s happening with your store today.</p></div><div className="welcomeTag">PANCHAGARH MART <span>● LIVE ADMIN</span></div></div>
        {error && <div className="alert" role="alert">{error}<button className="linkBtn" onClick={refresh}>Retry</button></div>}
        {notice && <div className="success" role="status">{notice}</div>}
        {loadingData && !data.overview ? <AdminSkeleton /> : <AdminSection key={section} section={section} data={data} refresh={refresh} setSection={setSection} notify={setMessage} />}
        <button className="refresh" onClick={refresh} disabled={loadingData}><RefreshCw size={15} />{loadingData ? "Refreshing…" : "Refresh data"}</button>
      </section>
    </main>
  </div>;
}

function RouteNotFound() { return <div className="center"><p>That page is not available.</p><a href="/">Back to Panchagarh Mart</a></div>; }
function Setup() { return <div className="authWrap"><div className="authCard"><div className="brandIcon big">P</div><h1>Connect Supabase</h1><p>Add <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_PUBLISHABLE_KEY</code> to your Replit environment, then reload the app.</p><p>The key must begin with <code>sb_publishable_</code>. Never use a secret key in frontend code.</p></div></div>; }
function Login() {
  const [email, setEmail] = useState(""); const [password, setPassword] = useState(""); const [busy, setBusy] = useState(false); const [msg, setMsg] = useState("");
  async function submit(e) { e.preventDefault(); setBusy(true); setMsg(""); const { error: authError } = await supabase.auth.signInWithPassword({ email, password }); setMsg(authError?.message || ""); setBusy(false); }
  return <div className="authWrap"><form className="authCard" onSubmit={submit}><div className="brandIcon big">P</div><p className="eyebrow">PANCHAGARH MART</p><h1>Admin Login</h1><p>Sign in to manage your online store.</p><label>Email address<input type="email" value={email} onChange={e => setEmail(e.target.value)} required placeholder="admin@example.com" /></label><label>Password<input type="password" value={password} onChange={e => setPassword(e.target.value)} required placeholder="Your password" /></label>{msg && <div className="alert">{msg}</div>}<button className="primary full" disabled={busy}>{busy ? "Signing in…" : "Sign in to Dashboard"}</button></form></div>;
}
function AdminSkeleton() { return <div className="stats">{[1, 2, 3, 4].map(n => <div className="stat" key={n}><div className="skeletonBlock" /><div className="skeletonLine" /><div className="skeletonLine short" /></div>)}</div>; }
function AdminSection({ section, data, refresh, setSection, notify }) {
  switch (section) {
    case "Dashboard": return <Dashboard data={data} setSection={setSection} />;
    case "Products": return <Products products={data.products} refresh={refresh} notify={notify} />;
    case "Orders": return <Orders />;
    case "Customers": return <Customers />;
    case "Categories": return <Categories refresh={refresh} notify={notify} />;
    case "Inventory": return <Inventory products={data.products} refresh={refresh} notify={notify} />;
    case "Discounts": return <Discounts notify={notify} />;
    case "Marketing": return <Campaigns channel="marketing" notify={notify} />;
    case "Email": return <Campaigns channel="email" notify={notify} />;
    case "Chat": return <Support />;
    case "Settings": return <SettingsView notify={notify} />;
    case "Analytics": return <Analytics data={data} />;
    case "Finance": return <Finance data={data} />;
    case "Reports": return <Reports data={data} />;
    default: return <Empty text="This section is not available." />;
  }
}
function Dashboard({ data, setSection }) {
  const { products, orders, customers } = data;
  const summary = data.overview?.summary || {};
  const revenue = Number(summary.delivered_revenue ?? orders.filter(o => o.status === "delivered").reduce((sum, o) => sum + Number(o.total_amount || 0), 0));
  const cards = [["Total Products", data.overview?.productCount ?? products.length, Package, "purple"], ["Total Orders", data.overview?.orderCount ?? orders.length, ShoppingCart, "blue"], ["Customers", data.overview?.customerCount ?? customers.length, Users, "green"], ["Delivered Revenue", money(revenue), Wallet, "orange"]];
  return <><div className="stats">{cards.map(([label, value, Icon, color]) => <div className="stat" key={label}><div className={`statIcon ${color}`}><Icon /></div><span>{label}</span><strong>{value}</strong><small>Live database figures</small></div>)}</div>
    <div className="grid2"><div className="panel"><div className="panelHead"><div><h2>Store Activity</h2><p>Latest orders from your store</p></div><button className="linkBtn" onClick={() => setSection("Orders")}>View all →</button></div>{orders.slice(0, 5).length ? orders.slice(0, 5).map(o => <div className="activity" key={o.id}><div className="activityIcon"><ShoppingCart /></div><div><b>{o.customer_name}</b><small>Order {o.order_number || `#${o.id}`} · {o.status}</small></div><strong>{money(o.total_amount)}</strong></div>) : <Empty text="No orders yet. New orders will appear here." />}</div>
      <div className="panel"><div className="panelHead"><div><h2>Inventory Snapshot</h2><p>Product stock status</p></div><button className="linkBtn" onClick={() => setSection("Inventory")}>Manage →</button></div><div className="inventoryLine"><span>Active products</span><b>{summary.active_product_count ?? products.filter(p => p.is_active).length}</b></div><div className="inventoryLine"><span>Low stock (5 or less)</span><b className="warningText">{summary.low_stock_count ?? products.filter(p => p.stock <= 5).length}</b></div><div className="inventoryLine"><span>Pending orders</span><b>{summary.pending_order_count ?? orders.filter(o => o.status === "pending").length}</b></div><button className="primary" onClick={() => setSection("Products")}><Plus size={16} /> Add a product</button></div></div>
    <div className="panel"><div className="panelHead"><div><h2>Recent Products</h2><p>Latest product listings</p></div><button className="linkBtn" onClick={() => setSection("Products")}>View all →</button></div><ProductTable products={products.slice(0, 5)} /></div></>;
}
function ProductTable({ products, onEdit, onDelete }) {
  if (!products.length) return <Empty text="No products have been added yet." />;
  return <div className="tableWrap"><table><thead><tr><th>PRODUCT</th><th>PRICE</th><th>STOCK</th><th>STATUS</th>{onEdit && <th>ACTIONS</th>}</tr></thead><tbody>{products.map(p => <tr key={p.id}><td><div className="productCell">{p.image_url ? <img src={p.image_url} alt="" /> : <div className="placeholder"><Package /></div>}<b>{p.name}</b></div></td><td>{money(p.price)}</td><td>{p.stock}</td><td><span className={`pill ${p.stock <= 5 ? "low" : ""}`}>{p.stock <= 5 ? "Low stock" : p.is_active ? "Active" : "Hidden"}</span></td>{onEdit && <td><button className="iconBtn" aria-label={`Edit ${p.name}`} onClick={() => onEdit(p)}><Pencil size={16} /></button><button className="iconBtn danger" aria-label={`Delete ${p.name}`} onClick={() => onDelete(p)}><Trash2 size={16} /></button></td>}</tr>)}</tbody></table></div>;
}
function Products({ products, refresh, notify }) {
  const [open, setOpen] = useState(false); const [edit, setEdit] = useState(null); const [q, setQ] = useState("");
  async function remove(product) {
    if (!window.confirm(`Delete “${product.name}”?`)) return;
    try {
      await deleteProduct(product.id);
      await refresh();
      if (product.image_path) {
        try { await deleteProductImage(product.image_path); }
        catch (e) { notify(`Product deleted, but its image could not be removed: ${e.message}`); return; }
      }
      notify("Product deleted.");
    } catch (e) { window.alert(e.message); }
  }
  const filtered = products.filter(p => `${p.name} ${p.sku || ""}`.toLowerCase().includes(q.toLowerCase()));
  return <><div className="panel"><div className="panelHead"><div><h2>Products</h2><p>Add and manage live store inventory</p></div><button className="primary" onClick={() => { setEdit(null); setOpen(true); }}><Plus size={16} /> Add Product</button></div><input className="filter" aria-label="Filter products" placeholder="Search products…" value={q} onChange={e => setQ(e.target.value)} /><ProductTable products={filtered} onEdit={p => { setEdit(p); setOpen(true); }} onDelete={remove} /></div>{open && <ProductModal product={edit} close={() => setOpen(false)} done={message => { setOpen(false); refresh(); notify(message || "Product saved successfully."); }} />}</>;
}
function ProductModal({ product, close, done }) {
  const [name, setName] = useState(product?.name || ""); const [price, setPrice] = useState(product?.price ?? ""); const [stock, setStock] = useState(product?.stock ?? 0);
  const [description, setDescription] = useState(product?.description || ""); const [sku, setSku] = useState(product?.sku || ""); const [active, setActive] = useState(product?.is_active ?? true);
  const [category, setCategory] = useState(product?.category_id || ""); const [categories, setCategories] = useState([]); const [file, setFile] = useState(null); const [busy, setBusy] = useState(false); const [msg, setMsg] = useState("");
  useEffect(() => { listCategories().then(setCategories).catch(e => setMsg(e.message)); }, []);
  async function save(e) { e.preventDefault(); setBusy(true); setMsg(""); let image = { image_url: product?.image_url || null, image_path: product?.image_path || null }; let uploadedPath = null;
    try {
      if (file) { image = await uploadProductImage(file); uploadedPath = image.image_path; }
      await saveProduct({ ...product, name, price: Number(price), stock: Number(stock), description, sku, category_id: category || null, is_active: active, ...image });
      if (file && product?.image_path) {
        try { await deleteProductImage(product.image_path); }
        catch (cleanupError) { done(`Product saved, but the previous image could not be removed: ${cleanupError.message}`); return; }
      }
      done();
    }
    catch (err) {
      if (uploadedPath) {
        try { await deleteProductImage(uploadedPath); }
        catch (cleanupError) { setMsg(`${err.message} Uploaded image cleanup also failed: ${cleanupError.message}`); return; }
      }
      setMsg(err.message);
    } finally { setBusy(false); }
  }
  return <div className="modalBack"><form className="modal" onSubmit={save}><div className="panelHead"><div><h2>{product ? "Edit Product" : "Add Product"}</h2><p>Product details visible to your customers</p></div><button type="button" className="iconBtn" onClick={close}><X /></button></div><label>Product name<input value={name} onChange={e => setName(e.target.value)} required /></label><div className="form2"><label>Price (৳)<input type="number" min="0" step="0.01" value={price} onChange={e => setPrice(e.target.value)} required /></label><label>Stock quantity<input type="number" min="0" step="1" value={stock} onChange={e => setStock(e.target.value)} required /></label></div><div className="form2"><label>SKU<input value={sku} onChange={e => setSku(e.target.value)} /></label><label>Category<select value={category} onChange={e => setCategory(e.target.value)}><option value="">Uncategorized</option>{categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label></div><label>Description<textarea value={description} onChange={e => setDescription(e.target.value)} rows="3" /></label><label>Product image<input type="file" accept="image/*" onChange={e => setFile(e.target.files?.[0] || null)} /></label><label className="checkLabel"><input type="checkbox" checked={active} onChange={e => setActive(e.target.checked)} /> Visible in storefront</label>{msg && <div className="alert">{msg}</div>}<div className="modalActions"><button type="button" className="secondaryBtn" onClick={close}>Cancel</button><button className="primary" disabled={busy}>{busy ? "Saving…" : "Save Product"}</button></div></form></div>;
}
function Orders() {
  const [items, setItems] = useState([]); const [search, setSearch] = useState(""); const [status, setStatus] = useState(""); const [busy, setBusy] = useState(false); const [error, setError] = useState(""); const [selected, setSelected] = useState(null); const [lines, setLines] = useState([]);
  async function load() { setBusy(true); setError(""); try { setItems(await listOrders({ search, status })); } catch (e) { setError(e.message); } finally { setBusy(false); } }
  useEffect(() => { load(); }, [search, status]);
  async function showOrder(order) { setSelected(order); try { setLines(await getOrderItems(order.id)); } catch (e) { setError(e.message); } }
  async function change(id, changes) { try { await updateOrder(id, changes); await load(); if (selected?.id === id) setSelected(current => ({ ...current, ...changes })); } catch (e) { setError(e.message); } }
  return <><div className="panel"><div className="panelHead"><div><h2>Orders</h2><p>Review orders and keep customers updated</p></div></div><div className="toolbarFilters"><input className="filter" placeholder="Find order, name or phone" value={search} onChange={e => setSearch(e.target.value)} /><select className="filter" aria-label="Filter by status" value={status} onChange={e => setStatus(e.target.value)}><option value="">All statuses</option>{statusOptions.map(s => <option key={s}>{s}</option>)}</select></div>{error && <div className="alert">{error}</div>}{busy ? <AdminSkeleton /> : items.length ? <div className="tableWrap"><table><thead><tr><th>ORDER</th><th>CUSTOMER</th><th>PHONE</th><th>TOTAL</th><th>STATUS</th><th>DATE</th><th>DETAILS</th></tr></thead><tbody>{items.map(o => <tr key={o.id}><td>{o.order_number || `#${o.id}`}</td><td>{o.customer_name}</td><td>{o.phone}</td><td>{money(o.total_amount)}</td><td><select className="inlineSelect" value={o.status} onChange={e => change(o.id, { status: e.target.value })}>{statusOptions.map(s => <option key={s}>{s}</option>)}</select></td><td>{date(o.created_at)}</td><td><button className="linkBtn" onClick={() => showOrder(o)}>Open</button></td></tr>)}</tbody></table></div> : <Empty text="No matching orders." />}</div>{selected && <div className="modalBack" onClick={() => setSelected(null)}><div className="modal" onClick={e => e.stopPropagation()}><div className="panelHead"><div><h2>{selected.order_number || `Order #${selected.id}`}</h2><p>{selected.customer_name} · {selected.phone}</p></div><button className="iconBtn" onClick={() => setSelected(null)}><X /></button></div><p className="muted">{selected.shipping_address}</p><p className="muted">Cash on delivery · {selected.payment_status || "unpaid"} · {date(selected.created_at)}</p>{lines.map(line => <div className="inventoryLine" key={line.id}><span>{line.product_name} × {line.quantity}</span><b>{money(line.line_total)}</b></div>)}<div className="inventoryLine"><span>Total</span><b>{money(selected.total_amount)}</b></div><label>Payment status<select value={selected.payment_status || "unpaid"} onChange={e => change(selected.id, { payment_status: e.target.value })}><option>unpaid</option><option>paid</option><option>refunded</option></select></label></div></div>}</>;
}
function Customers() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");
  const [edit, setEdit] = useState(null);
  const [busy, setBusy] = useState(false);
  async function load() {
    try { setItems(await listCustomers({ search })); setError(""); }
    catch (e) { setError(e.message); }
  }
  useEffect(() => { load(); }, [search]);
  async function save(e) {
    e.preventDefault();
    setBusy(true);
    try {
      if (edit.id) await updateCustomer(edit.id, edit);
      else await createCustomer(edit);
      setEdit(null);
      await load();
    } catch (e2) { setError(e2.message); }
    finally { setBusy(false); }
  }
  async function remove(customer) {
    if (!window.confirm(`Delete ${customer.full_name} from the customer list? Historical order snapshots will remain.`)) return;
    try { await deleteCustomer(customer.id); await load(); }
    catch (e) { setError(e.message); }
  }
  return <>
    <div className="panel">
      <div className="panelHead">
        <div><h2>Customers</h2><p>Customer profiles created by orders or added by your team</p></div>
        <button className="primary" onClick={() => setEdit({ full_name: "", phone: "", email: "" })}><Plus size={16} />Add customer</button>
      </div>
      <input className="filter" placeholder="Search name, phone or email" value={search} onChange={e => setSearch(e.target.value)} />
      {error && <div className="alert">{error}</div>}
      {items.length ? <div className="tableWrap"><table><thead><tr><th>NAME</th><th>PHONE</th><th>EMAIL</th><th>JOINED</th><th>ACTIONS</th></tr></thead><tbody>
        {items.map(c => <tr key={c.id}><td>{c.full_name}</td><td>{c.phone}</td><td>{c.email || "—"}</td><td>{date(c.created_at)}</td><td><button className="iconBtn" onClick={() => setEdit(c)} aria-label={`Edit ${c.full_name}`}><Pencil size={15} /></button><button className="iconBtn danger" onClick={() => remove(c)} aria-label={`Delete ${c.full_name}`}><Trash2 size={15} /></button></td></tr>)}
      </tbody></table></div> : <Empty text="No customer profiles found." />}
    </div>
    {edit && <div className="modalBack"><form className="modal" onSubmit={save}>
      <div className="panelHead"><h2>{edit.id ? "Edit customer" : "Add customer"}</h2><button type="button" className="iconBtn" onClick={() => setEdit(null)}><X /></button></div>
      <label>Full name<input required maxLength="120" value={edit.full_name} onChange={e => setEdit({ ...edit, full_name: e.target.value })} /></label>
      <label>Phone<input required maxLength="40" value={edit.phone} onChange={e => setEdit({ ...edit, phone: e.target.value })} /></label>
      <label>Email<input type="email" value={edit.email || ""} onChange={e => setEdit({ ...edit, email: e.target.value })} /></label>
      <div className="modalActions"><button type="button" className="secondaryBtn" onClick={() => setEdit(null)}>Cancel</button><button className="primary" disabled={busy}>{busy ? "Saving…" : "Save customer"}</button></div>
    </form></div>}
  </>;
}
function Categories({ refresh, notify }) {
  const [items, setItems] = useState([]); const [edit, setEdit] = useState(null); const [error, setError] = useState("");
  async function load() { try { setItems(await listCategories()); setError(""); } catch (e) { setError(e.message); } }
  useEffect(() => { load(); }, []);
  async function save(e) { e.preventDefault(); try { await saveCategory(edit); setEdit(null); load(); refresh(); notify("Category saved."); } catch (e2) { setError(e2.message); } }
  async function remove(row) { if (!confirm(`Delete category “${row.name}”?`)) return; try { await deleteCategory(row.id); load(); refresh(); } catch (e) { setError(e.message); } }
  return <div className="panel"><div className="panelHead"><div><h2>Categories</h2><p>Organize products into storefront browse groups</p></div><button className="primary" onClick={() => setEdit({ name: "", description: "", is_active: true })}><Plus size={16} />Add category</button></div>{error && <div className="alert">{error}</div>}{items.length ? <div className="tableWrap"><table><thead><tr><th>CATEGORY</th><th>DESCRIPTION</th><th>STATUS</th><th>ACTIONS</th></tr></thead><tbody>{items.map(c => <tr key={c.id}><td><b>{c.name}</b></td><td>{c.description || "—"}</td><td>{c.is_active ? "Active" : "Hidden"}</td><td><button className="iconBtn" onClick={() => setEdit(c)}><Pencil size={15} /></button><button className="iconBtn danger" onClick={() => remove(c)}><Trash2 size={15} /></button></td></tr>)}</tbody></table></div> : <Empty text="No categories yet." />}{edit && <div className="modalBack"><form className="modal" onSubmit={save}><div className="panelHead"><h2>{edit.id ? "Edit category" : "New category"}</h2><button className="iconBtn" type="button" onClick={() => setEdit(null)}><X /></button></div><label>Name<input required value={edit.name} onChange={e => setEdit({ ...edit, name: e.target.value })} /></label><label>Description<textarea value={edit.description || ""} onChange={e => setEdit({ ...edit, description: e.target.value })} /></label><label className="checkLabel"><input type="checkbox" checked={edit.is_active} onChange={e => setEdit({ ...edit, is_active: e.target.checked })} /> Available to shoppers</label><button className="primary">Save category</button></form></div>}</div>;
}
function Inventory({ products, refresh, notify }) {
  const [movements, setMovements] = useState([]); const [productId, setProductId] = useState(""); const [delta, setDelta] = useState(""); const [reason, setReason] = useState(""); const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  async function load() { try { setMovements(await listInventoryMovements(productId)); setError(""); } catch (e) { setError(e.message); } }
  useEffect(() => { load(); }, [productId]);
  async function submit(e) { e.preventDefault(); setBusy(true); try { await adjustInventory(productId, Number(delta), reason); setDelta(""); setReason(""); await load(); refresh(); notify("Stock adjustment recorded."); } catch (e2) { setError(e2.message); } finally { setBusy(false); } }
  return <><div className="grid2"><div className="panel"><div className="panelHead"><div><h2>Adjust stock</h2><p>Each change is recorded in the inventory ledger</p></div></div><form className="stackForm" onSubmit={submit}><label>Product<select required value={productId} onChange={e => setProductId(e.target.value)}><option value="">Choose a product</option>{products.map(p => <option key={p.id} value={p.id}>{p.name} · {p.stock} in stock</option>)}</select></label><label>Quantity change<input type="number" step="1" required value={delta} onChange={e => setDelta(e.target.value)} placeholder="Use a minus sign to remove stock" /></label><label>Reason<input required value={reason} onChange={e => setReason(e.target.value)} placeholder="e.g. supplier delivery" /></label>{error && <div className="alert">{error}</div>}<button className="primary" disabled={busy || !products.length}>{busy ? "Recording…" : "Record adjustment"}</button></form></div><div className="panel"><div className="panelHead"><div><h2>Current stock</h2><p>Live product quantities</p></div></div>{products.length ? products.map(p => <div className="inventoryLine" key={p.id}><span>{p.name}</span><b className={p.stock <= 5 ? "warningText" : ""}>{p.stock}</b></div>) : <Empty text="No products available." />}</div></div><div className="panel"><div className="panelHead"><div><h2>Movement history</h2><p>Recent stock changes</p></div><select className="filter compact" aria-label="Filter inventory movements" value={productId} onChange={e => setProductId(e.target.value)}><option value="">All products</option>{products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></div>{movements.length ? <div className="tableWrap"><table><thead><tr><th>PRODUCT</th><th>CHANGE</th><th>REASON</th><th>DATE</th></tr></thead><tbody>{movements.map(m => <tr key={m.id}><td>{m.products?.name || "Product"}</td><td className={m.quantity_delta < 0 ? "warningText" : ""}>{m.quantity_delta > 0 ? "+" : ""}{m.quantity_delta}</td><td>{m.reason}</td><td>{date(m.created_at)}</td></tr>)}</tbody></table></div> : <Empty text="No inventory movements recorded." />}</div></>;
}
function Discounts({ notify }) {
  const [items, setItems] = useState([]); const [edit, setEdit] = useState(null); const [error, setError] = useState("");
  async function load() { try { setItems(await listDiscounts()); setError(""); } catch (e) { setError(e.message); } }
  useEffect(() => { load(); }, []);
  async function save(e) { e.preventDefault(); try { await saveDiscount(edit); setEdit(null); load(); notify("Discount saved."); } catch (e2) { setError(e2.message); } }
  async function remove(d) { if (!confirm(`Delete discount ${d.code}?`)) return; try { await deleteDiscount(d.id); load(); } catch (e) { setError(e.message); } }
  return <div className="panel"><div className="panelHead"><div><h2>Discounts</h2><p>Manage codes applied during Cash on Delivery checkout</p></div><button className="primary" onClick={() => setEdit({ code: "", discount_type: "percentage", value: "", minimum_order: 0, usage_limit: "", is_active: true })}><Plus size={16} />New discount</button></div>{error && <div className="alert">{error}</div>}{items.length ? <div className="tableWrap"><table><thead><tr><th>CODE</th><th>OFFER</th><th>MINIMUM ORDER</th><th>USED</th><th>STATUS</th><th>ACTIONS</th></tr></thead><tbody>{items.map(d => <tr key={d.id}><td><b>{d.code}</b></td><td>{d.discount_type === "percentage" ? `${d.value}%` : money(d.value)}</td><td>{money(d.minimum_order)}</td><td>{d.used_count}{d.usage_limit ? ` / ${d.usage_limit}` : ""}</td><td>{d.is_active ? "Active" : "Paused"}</td><td><button className="iconBtn" onClick={() => setEdit(d)}><Pencil size={15} /></button><button className="iconBtn danger" onClick={() => remove(d)}><Trash2 size={15} /></button></td></tr>)}</tbody></table></div> : <Empty text="No discount codes created." />}{edit && <div className="modalBack"><form className="modal" onSubmit={save}><div className="panelHead"><h2>{edit.id ? "Edit discount" : "New discount"}</h2><button type="button" className="iconBtn" onClick={() => setEdit(null)}><X /></button></div><label>Code<input required value={edit.code} onChange={e => setEdit({ ...edit, code: e.target.value.toUpperCase() })} /></label><div className="form2"><label>Type<select value={edit.discount_type} onChange={e => setEdit({ ...edit, discount_type: e.target.value })}><option value="percentage">Percentage</option><option value="fixed">Fixed amount</option></select></label><label>Value<input type="number" min="0.01" step="0.01" required value={edit.value} onChange={e => setEdit({ ...edit, value: e.target.value })} /></label></div><div className="form2"><label>Minimum order (৳)<input type="number" min="0" value={edit.minimum_order} onChange={e => setEdit({ ...edit, minimum_order: e.target.value })} /></label><label>Usage limit<input type="number" min="0" value={edit.usage_limit ?? ""} onChange={e => setEdit({ ...edit, usage_limit: e.target.value })} placeholder="No limit" /></label></div><div className="form2"><label>Starts at<input type="datetime-local" value={edit.starts_at?.slice(0, 16) || ""} onChange={e => setEdit({ ...edit, starts_at: e.target.value ? new Date(e.target.value).toISOString() : null })} /></label><label>Ends at<input type="datetime-local" value={edit.ends_at?.slice(0, 16) || ""} onChange={e => setEdit({ ...edit, ends_at: e.target.value ? new Date(e.target.value).toISOString() : null })} /></label></div><label className="checkLabel"><input type="checkbox" checked={edit.is_active} onChange={e => setEdit({ ...edit, is_active: e.target.checked })} /> Active at checkout</label><button className="primary">Save discount</button></form></div>}</div>;
}
function Campaigns({ channel, notify }) {
  const [items, setItems] = useState([]); const [edit, setEdit] = useState(null); const [error, setError] = useState("");
  async function load() { try { setItems(await listCampaigns(channel)); setError(""); } catch (e) { setError(e.message); } }
  useEffect(() => { load(); }, [channel]);
  async function save(e) { e.preventDefault(); try { await saveCampaign({ ...edit, channel }); setEdit(null); load(); notify("Campaign saved."); } catch (e2) { setError(e2.message); } }
  async function remove(c) { if (!confirm(`Delete campaign “${c.name}”?`)) return; try { await deleteCampaign(c.id); load(); } catch (e) { setError(e.message); } }
  const label = channel === "email" ? "Email campaigns" : "Marketing campaigns";
  return <div className="panel"><div className="panelHead"><div><h2>{label}</h2><p>Compose and organize campaign drafts and schedules</p></div><button className="primary" onClick={() => setEdit({ name: "", subject: "", body: "", status: "draft", scheduled_at: "" })}><Plus size={16} />Create campaign</button></div>{error && <div className="alert">{error}</div>}{items.length ? <div className="campaignList">{items.map(c => <article className="campaignCard" key={c.id}><div className="campaignIcon">{channel === "email" ? <Mail /> : <Megaphone />}</div><div className="campaignBody"><div className="campaignMeta"><b>{c.name}</b><span className="pill">{c.status}</span></div><p>{c.subject || "No subject"} · Created {date(c.created_at)}</p>{c.scheduled_at && <small>Scheduled {date(c.scheduled_at)}</small>}</div><button className="iconBtn" onClick={() => setEdit(c)} aria-label="Edit campaign"><Pencil size={15} /></button><button className="iconBtn danger" onClick={() => remove(c)} aria-label="Delete campaign"><Trash2 size={15} /></button></article>)}</div> : <Empty text={`No ${channel} campaigns yet.`} />}{edit && <div className="modalBack"><form className="modal" onSubmit={save}><div className="panelHead"><h2>{edit.id ? "Edit campaign" : "Create campaign"}</h2><button type="button" className="iconBtn" onClick={() => setEdit(null)}><X /></button></div><label>Campaign name<input required value={edit.name} onChange={e => setEdit({ ...edit, name: e.target.value })} /></label><label>Subject<input value={edit.subject || ""} onChange={e => setEdit({ ...edit, subject: e.target.value })} /></label><label>Message<textarea rows="5" value={edit.body || ""} onChange={e => setEdit({ ...edit, body: e.target.value })} /></label><div className="form2"><label>Status<select value={edit.status || "draft"} onChange={e => setEdit({ ...edit, status: e.target.value })}><option value="draft">Draft</option><option value="scheduled">Scheduled</option><option value="archived">Archived</option></select></label><label>Schedule time<input type="datetime-local" value={edit.scheduled_at?.slice(0, 16) || ""} onChange={e => setEdit({ ...edit, scheduled_at: e.target.value ? new Date(e.target.value).toISOString() : null })} /></label></div><p className="muted">Saving a campaign organizes content; sending is not configured.</p><button className="primary">Save campaign</button></form></div>}</div>;
}
function Support() {
  const [items, setItems] = useState([]); const [status, setStatus] = useState(""); const [error, setError] = useState(""); const [reply, setReply] = useState({});
  async function load() { try { setItems(await listSupportMessages({ status })); setError(""); } catch (e) { setError(e.message); } }
  useEffect(() => { load(); }, [status]);
  async function update(item, changes) { try { await updateSupportMessage(item.id, { ...item, ...changes }); await load(); } catch (e) { setError(e.message); } }
  return <div className="panel"><div className="panelHead"><div><h2>Customer chat</h2><p>Store inquiries and support conversations</p></div><select className="filter compact" value={status} onChange={e => setStatus(e.target.value)}><option value="">All conversations</option><option value="new">New</option><option value="in_progress">In progress</option><option value="resolved">Resolved</option></select></div>{error && <div className="alert">{error}</div>}{items.length ? <div className="supportList">{items.map(m => <article className="supportCard" key={m.id}><div className="supportTop"><div><b>{m.customer_name}</b><small>{m.phone}{m.email ? ` · ${m.email}` : ""} · {date(m.created_at)}</small></div><select value={m.status} onChange={e => update(m, { status: e.target.value })}><option value="new">New</option><option value="in_progress">In progress</option><option value="resolved">Resolved</option></select></div><h3>{m.subject}</h3><p>{m.message}</p>{m.admin_reply && <div className="adminReply"><b>Team reply</b><p>{m.admin_reply}</p></div>}<form className="replyForm" onSubmit={e => { e.preventDefault(); update(m, { status: "in_progress", admin_reply: reply[m.id] || m.admin_reply || "" }); }}><input placeholder="Write an admin reply…" value={reply[m.id] ?? m.admin_reply ?? ""} onChange={e => setReply({ ...reply, [m.id]: e.target.value })} /><button className="primary" disabled={!reply[m.id]?.trim()}>Save reply</button><button type="button" className="secondaryBtn" onClick={() => update(m, { status: "resolved" })}>Resolve</button></form></article>)}</div> : <Empty text="No support messages yet." />}</div>;
}
function SettingsView({ notify }) {
  const [form, setForm] = useState(null); const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  useEffect(() => { getStoreSettings().then(s => setForm(s || { store_name: "Panchagarh Mart", support_phone: "", support_email: "", store_address: "", delivery_fee: 0 })).catch(e => setError(e.message)); }, []);
  async function save(e) { e.preventDefault(); setBusy(true); try { setForm(await saveStoreSettings(form)); notify("Store settings updated."); } catch (e2) { setError(e2.message); } finally { setBusy(false); } }
  if (!form) return error ? <div className="alert">{error}</div> : <AdminSkeleton />;
  return <div className="panel settingsPanel"><div className="panelHead"><div><h2>Store settings</h2><p>Public contact details and delivery fee used at checkout</p></div></div><form className="stackForm" onSubmit={save}><label>Store name<input required value={form.store_name} onChange={e => setForm({ ...form, store_name: e.target.value })} /></label><div className="form2"><label>Support phone<input value={form.support_phone} onChange={e => setForm({ ...form, support_phone: e.target.value })} /></label><label>Support email<input type="email" value={form.support_email} onChange={e => setForm({ ...form, support_email: e.target.value })} /></label></div><label>Store address<textarea value={form.store_address} onChange={e => setForm({ ...form, store_address: e.target.value })} rows="3" /></label><label>Delivery fee (৳)<input type="number" min="0" step="0.01" required value={form.delivery_fee} onChange={e => setForm({ ...form, delivery_fee: e.target.value })} /></label>{error && <div className="alert">{error}</div>}<button className="primary" disabled={busy}>{busy ? "Saving…" : "Save settings"}</button></form></div>;
}
function Analytics({ data }) {
  const summary = data.overview?.summary || {};
  const delivered = data.orders.filter(o => o.status === "delivered");
  const total = Number(summary.delivered_revenue ?? delivered.reduce((s, o) => s + Number(o.total_amount || 0), 0));
  const statuses = statusOptions.map(status => [status, Number(summary.order_status_counts?.[status] ?? data.orders.filter(o => o.status === status).length)]);
  const max = Math.max(1, ...statuses.map(x => x[1]));
  const lowStock = data.products.filter(p => p.stock <= 5);
  return <><div className="stats"><Metric label="Orders tracked" value={data.overview?.orderCount ?? data.orders.length} icon={ClipboardList} /><Metric label="Delivered value" value={money(total)} icon={TrendingUp} /><Metric label="Active products" value={summary.active_product_count ?? data.products.filter(p => p.is_active).length} icon={Package} /><Metric label="Customers" value={data.overview?.customerCount ?? data.customers.length} icon={Users} /></div><div className="grid2"><div className="panel"><div className="panelHead"><div><h2>Order status mix</h2><p>Current order totals by workflow stage</p></div></div>{statuses.map(([s, count]) => <div className="barRow" key={s}><span>{s}</span><div className="barTrack"><i style={{ width: `${count / max * 100}%` }} /></div><b>{count}</b></div>)}</div><div className="panel"><div className="panelHead"><div><h2>Stock watch</h2><p>Products at five units or fewer</p></div></div>{lowStock.length ? lowStock.slice(0, 8).map(p => <div className="inventoryLine" key={p.id}><span>{p.name}</span><b className="warningText">{p.stock} left</b></div>) : (summary.low_stock_count || 0) > 0 ? <p className="muted">{summary.low_stock_count} products need attention. Open Inventory to review the full list.</p> : <Empty text="No low-stock products." />}</div></div></>;
}
function Finance({ data }) {
  const summary = data.overview?.summary || {};
  const delivered = data.orders.filter(o => o.status === "delivered");
  const revenue = Number(summary.delivered_revenue ?? delivered.reduce((s, o) => s + Number(o.total_amount || 0), 0));
  const pending = Number(summary.unpaid_total ?? data.orders.filter(o => o.payment_status === "unpaid").reduce((s, o) => s + Number(o.total_amount || 0), 0));
  return <><div className="stats"><Metric label="Delivered sales" value={money(revenue)} icon={Wallet} /><Metric label="Cash collection pending" value={money(pending)} icon={Clock3} /><Metric label="Delivered orders" value={summary.delivered_order_count ?? delivered.length} icon={Check} /><Metric label="COD orders" value={summary.cod_order_count ?? data.orders.filter(o => o.payment_method === "cash_on_delivery").length} icon={Truck} /></div><div className="panel"><div className="panelHead"><div><h2>Recent order ledger</h2><p>Order totals and payment state; no payment gateway is connected</p></div></div><OrdersTable orders={data.orders.slice(0, 30)} /></div></>;
}
function Reports({ data }) {
  const delivered = data.orders.filter(o => o.status === "delivered");
  const summary = data.overview?.summary || {};
  return <div className="panel"><div className="panelHead"><div><h2>Store report</h2><p>Live summary from current store records</p></div><button className="secondaryBtn" onClick={() => window.print()}>Print report</button></div><div className="reportSummary"><div><span>Products</span><b>{data.overview?.productCount ?? data.products.length}</b></div><div><span>Customers</span><b>{data.overview?.customerCount ?? data.customers.length}</b></div><div><span>All orders</span><b>{data.overview?.orderCount ?? data.orders.length}</b></div><div><span>Delivered sales</span><b>{money(summary.delivered_revenue ?? delivered.reduce((s, o) => s + Number(o.total_amount || 0), 0))}</b></div><div><span>Pending orders</span><b>{summary.pending_order_count ?? data.orders.filter(o => o.status === "pending").length}</b></div><div><span>Low stock</span><b>{summary.low_stock_count ?? data.products.filter(p => p.stock <= 5).length}</b></div></div><h3 className="reportTitle">Latest order records</h3><OrdersTable orders={data.orders.slice(0, 20)} /></div>;
}
function OrdersTable({ orders }) { return orders.length ? <div className="tableWrap"><table><thead><tr><th>ORDER</th><th>CUSTOMER</th><th>TOTAL</th><th>PAYMENT</th><th>STATUS</th><th>DATE</th></tr></thead><tbody>{orders.map(o => <tr key={o.id}><td>{o.order_number || `#${o.id}`}</td><td>{o.customer_name}</td><td>{money(o.total_amount)}</td><td>{o.payment_status || "unpaid"}</td><td>{o.status}</td><td>{date(o.created_at)}</td></tr>)}</tbody></table></div> : <Empty text="No order records to report." />; }
function Metric({ label, value, icon: Icon }) { return <div className="stat"><div className="statIcon blue"><Icon /></div><span>{label}</span><strong>{value}</strong><small>Live database figures</small></div>; }
function Empty({ text }) { return <div className="empty"><Package size={28} /><p>{text}</p></div>; }

function Storefront() {
  const [products, setProducts] = useState([]); const [categories, setCategories] = useState([]); const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true); const [error, setError] = useState(""); const [search, setSearch] = useState(""); const [category, setCategory] = useState(""); const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false); const [checkout, setCheckout] = useState(false); const [busy, setBusy] = useState(false); const [orderResult, setOrderResult] = useState(null); const [checkoutError, setCheckoutError] = useState("");
  const [supportBusy, setSupportBusy] = useState(false); const [supportMessage, setSupportMessage] = useState(""); const [supportError, setSupportError] = useState("");
  useEffect(() => { Promise.all([listProducts({ publicOnly: true }), listCategories({ activeOnly: true }), getStoreSettings()]).then(([p, c, s]) => { setProducts(p || []); setCategories(c || []); setSettings(s); }).catch(e => setError(e.message)).finally(() => setLoading(false)); }, []);
  const filtered = useMemo(() => products.filter(p => (!category || p.category_id === category) && `${p.name} ${p.description || ""} ${p.categories?.name || ""}`.toLowerCase().includes(search.toLowerCase())), [products, category, search]);
  const itemCount = cartItemCount(cart);
  function add(product) { setCart(current => addCartProduct(current, product)); setCartOpen(true); }
  function changeQty(id, delta) { setCart(current => changeCartQuantity(current, id, delta)); }
  async function placeOrder(e) { e.preventDefault(); setBusy(true); setCheckoutError(""); try { const form = new FormData(e.currentTarget); const result = await placeCodOrder({ customer_name: form.get("name"), phone: form.get("phone"), email: form.get("email"), shipping_address: form.get("address"), delivery_notes: form.get("notes"), items: cart.map(item => ({ product_id: item.id, quantity: item.quantity })), discount_code: form.get("discount") }); setOrderResult(result); setCart([]); } catch (e2) { setCheckoutError(e2.message); } finally { setBusy(false); } }
  async function sendSupportMessage(e) {
    e.preventDefault();
    const form = e.currentTarget;
    const values = new FormData(form);
    setSupportBusy(true); setSupportError(""); setSupportMessage("");
    try {
      await submitSupportMessage({
        customer_name: values.get("customer_name"),
        phone: values.get("phone"),
        email: values.get("email"),
        message: values.get("message"),
      });
      form.reset();
      setSupportMessage("Message sent. The store team will follow up.");
    } catch (err) { setSupportError(err.message); }
    finally { setSupportBusy(false); }
  }
  return <div className="storefront"><header className="storeTop"><a href="/" className="storeLogo"><span className="storeMark">P</span><span><b>Panchagarh Mart</b><small>Good things, close to home</small></span></a><label className="storeSearch"><Search size={17} /><input aria-label="Search products" placeholder="Find something you need…" value={search} onChange={e => setSearch(e.target.value)} /></label><div className="storeActions"><a href="#catalog">Browse</a><a href={settings?.support_phone ? `tel:${settings.support_phone}` : "#contact"}>{settings?.support_phone || "Local support"}</a><button className="cartTrigger" onClick={() => { setCartOpen(true); setCheckout(false); }}><ShoppingCart size={16} /> Cart <span className="cartCount">{itemCount}</span></button></div></header>
    <section className="storeHero"><div className="storeHeroCopy"><span className="storeEyebrow">PANCHAGARH, DELIVERED</span><h1>Your everyday market, a little closer.</h1><p>Shop locally, order simply, and pay when your delivery arrives. Browse what’s in stock from Panchagarh Mart.</p><button className="heroCta" onClick={() => document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth" })}>Browse the market <ArrowUpRight size={15} /></button></div><div className="harvestGraphic" aria-hidden="true"><div className="sun"><span>PM</span></div></div></section>
    <main className="storeMain" id="catalog"><div className="storeCatalogHead"><div><span className="storeEyebrow">THE MARKET</span><h2>Shop the shelves</h2><p>Clear prices, fresh stock, cash on delivery.</p></div><span className="storeItemCount">{filtered.length} items</span></div>
      <div className="categoryRail"><button className={`categoryChip ${category === "" ? "selected" : ""}`} onClick={() => setCategory("")}>Everything</button>{categories.map(c => <button key={c.id} className={`categoryChip ${category === c.id ? "selected" : ""}`} onClick={() => setCategory(c.id)}>{c.name}</button>)}</div>
      {error && <div className="storeError">{error}<button className="retryButton" onClick={() => window.location.reload()}>Retry</button></div>}
      {loading ? <div className="storeGrid">{[1, 2, 3, 4].map(n => <div className="storeProduct" key={n}><div className="storeProductImage storeSkeleton" /><div className="storeProductInfo"><div className="storeSkeletonLine" /><div className="storeSkeletonLine short" /></div></div>)}</div> : filtered.length ? <div className="storeGrid">{filtered.map(p => <article className="storeProduct" key={p.id}><div className="storeProductImage">{p.image_url ? <img src={p.image_url} alt={p.name} loading="lazy" /> : <Package size={30} />}</div><div className="storeProductInfo"><small>{p.categories?.name || "Panchagarh Mart"}</small><h3>{p.name}</h3><div className="storePriceRow"><span className="storePrice">{money(p.price)}</span><button className="addCart" aria-label={`Add ${p.name} to cart`} onClick={() => add(p)}><Plus size={18} /></button></div><span className="stockNote">{p.stock} in stock</span></div></article>)}</div> : <div className="storeEmpty">{search || category ? "No products match that selection." : "Our shelves are being stocked. Please check back soon."}</div>}
    </main><footer className="storeFooter" id="contact">
      <div><b>{settings?.store_name || "Panchagarh Mart"}</b><p>A locally trusted online market for Panchagarh shoppers.</p><p>Cash on delivery available</p></div>
      <div><b>Store details</b><p>{settings?.support_phone || "Local support"}{settings?.support_email ? ` · ${settings.support_email}` : ""}</p>{settings?.store_address && <p>{settings.store_address}</p>}</div>
      <div className="storeContact"><b>Send the store a message</b><form onSubmit={sendSupportMessage}>
        <label>Your name<input name="customer_name" required minLength="2" maxLength="120" autoComplete="name" /></label>
        <label>Phone number<input name="phone" required minLength="5" maxLength="40" autoComplete="tel" /></label>
        <label>Email (optional)<input name="email" type="email" autoComplete="email" /></label>
        <label>Message<textarea name="message" required maxLength="4000" rows="3" /></label>
        {supportError && <p className="storeContactError" role="alert">{supportError}</p>}
        {supportMessage && <p className="storeContactSuccess" role="status">{supportMessage}</p>}
        <button className="storeContactSubmit" disabled={supportBusy}>{supportBusy ? "Sending…" : "Send message"}</button>
      </form></div>
    </footer>
    {cartOpen && <div className="cartBackdrop" onClick={() => setCartOpen(false)}><aside className="cartPanel" onClick={e => e.stopPropagation()}><div className="cartHead"><h2>{orderResult ? "Order placed" : checkout ? "Delivery details" : `Your cart (${itemCount})`}</h2><button className="plainClose" aria-label="Close cart" onClick={() => { setCartOpen(false); setOrderResult(null); }}><X /></button></div>
       {orderResult ? <div className="orderSuccess"><div className="storeMark" style={{ margin: "auto" }}><Check /></div><h2>Thank you for your order.</h2><p>Your order <b>{orderResult.order_number || `#${orderResult.order_id}`}</b> is in. Pay {money(orderResult.total_amount)} in cash when your delivery arrives.</p><button className="checkoutSubmit" onClick={() => { setOrderResult(null); setCartOpen(false); }}>Continue shopping</button></div> : checkout ? <form className="checkoutForm" onSubmit={placeOrder}><div className="codNote">Cash on delivery. Product prices, stock and totals are confirmed securely when you place your order.</div><label>Full name<input name="name" required minLength="2" maxLength="120" autoComplete="name" /></label><label>Phone number<input name="phone" required minLength="5" maxLength="40" autoComplete="tel" /></label><label>Email (optional)<input name="email" type="email" autoComplete="email" /></label><label>Delivery address<textarea name="address" required minLength="5" maxLength="500" autoComplete="street-address" /></label><label>Delivery notes (optional)<textarea name="notes" /></label><label>Discount code (optional)<input name="discount" /></label>{checkoutError && <div className="storeError">{checkoutError}</div>}<div className="cartTotal"><span>Items</span><span>{itemCount}</span></div><button className="checkoutSubmit" disabled={busy}>{busy ? "Placing order…" : "Place Cash on Delivery order"}</button><button type="button" className="plainClose" onClick={() => setCheckout(false)}>Back to cart</button></form> : cart.length ? <><div className="cartLines">{cart.map(item => <div className="cartLine" key={item.id}>{item.image_url ? <img src={item.image_url} alt="" /> : <div className="cartThumb"><Package size={18} /></div>}<div><h4>{item.name}</h4><small>{money(item.price)} each</small><div className="qtyControl"><button aria-label="Remove one" onClick={() => changeQty(item.id, -1)}><Minus size={13} /></button><span>{item.quantity}</span><button aria-label="Add one" onClick={() => changeQty(item.id, 1)}><Plus size={13} /></button></div></div><b>{money(Number(item.price) * item.quantity)}</b></div>)}</div><div className="cartTotal"><span>Merchandise subtotal</span><span>{money(cartSubtotal(cart))}</span></div><p className="cartHint">Delivery fee and discounts are calculated at checkout.</p><button className="checkoutSubmit" onClick={() => setCheckout(true)}>Continue to delivery</button></> : <div className="storeEmpty">Your cart is empty. Add a few things from the market.</div>}</aside></div>}
  </div>;
}
export default App;
