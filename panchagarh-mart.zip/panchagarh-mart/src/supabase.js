import { createClient } from "@supabase/supabase-js";

const url = import.meta.env.VITE_SUPABASE_URL?.trim();
const key =
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY?.trim() ||
  import.meta.env.VITE_SUPABASE_ANON_KEY?.trim();

const validProjectUrl = (() => {
  if (!url) return false;

  try {
    const parsed = new URL(url);
    const isHttps = parsed.protocol === "https:";
    const isLocalHttp =
      parsed.protocol === "http:" &&
      ["localhost", "127.0.0.1"].includes(parsed.hostname);

    return (
      (isHttps || isLocalHttp) &&
      parsed.pathname === "/" &&
      !parsed.search &&
      !parsed.hash
    );
  } catch {
    return false;
  }
})();

const isPublicKey =
  key?.startsWith("sb_publishable_") || key?.startsWith("eyJ");
const isSecretKey = key?.startsWith("sb_secret_");

export const supabase =
  url && validProjectUrl && key && isPublicKey && !isSecretKey
    ? createClient(url, key)
    : null;